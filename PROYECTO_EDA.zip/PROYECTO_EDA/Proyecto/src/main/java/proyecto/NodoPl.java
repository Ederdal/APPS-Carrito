
package proyecto;

public class NodoPl {
    public String nombre;
    public int cantidad,contador;
    public float precio;
    public NodoPl sig, ant;
    
    public NodoPl(int cont,String n, int cant, float p, NodoPl s, NodoPl a){
        contador=cont;
        nombre=n;
        cantidad=cant;
        precio=p;
        sig=s;
        ant=a;
    }
    public NodoPl(int cont,String n, int c, float p){
        contador=cont;
        nombre=n;
        cantidad=c;
        precio=p;
        sig=null;
        ant=null;
    }
    
}
