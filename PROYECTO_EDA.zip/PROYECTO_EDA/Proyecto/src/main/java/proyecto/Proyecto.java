package proyecto;
import javax.swing.JOptionPane;
public class Proyecto {
    public static void main(String[] args) {
        String nom;
        int op=0,e,c;
        float p,total,price;
        Lista ls=new Lista();
        Cola cl=new Cola();
        do{
            op=Integer.parseInt(JOptionPane.showInputDialog(null,
                    "------ Platillos ------"
                    +"\n1.- Insertar un Platillo"
                    + "\n2.- Muestra el menu"
                    + "\n3.- Buscar platillo"
                    + "\n\n\n------ Pedidos ------"
                    + "\n11.- Tomar Lugar"
                            
                    + "\n12.- Atender primer pedido"
                    + "\n13.- Mostrar fila"
                    + "\n\n\n20.- Salir",
                    20));
            switch(op){
                case 1:
                    nom=JOptionPane.showInputDialog(null,
                    "Introduce el nombre del platillo");
                    e=Integer.parseInt(JOptionPane.showInputDialog(null,
                    "Inserta la cantidad"));
                    p=Float.parseFloat(JOptionPane.showInputDialog(null,
                    "Introduce el Precio\ndel platillo"));
                    ls.insertEnd(nom, e, p);
                break;
                case 2:
                    ls.printLista();
                break;
                case 3:
                    nom=JOptionPane.showInputDialog(null,
                    "Introduce el nombre del platillo");
                    ls.findProduct(nom);
                break;
                case 11:
                    do{
                        nom=JOptionPane.showInputDialog(null,
                        "Introduce el nombre de la persona");
                        e=Integer.parseInt(JOptionPane.showInputDialog(null,
                        "Inserta el producto"));
                        c=Integer.parseInt(JOptionPane.showInputDialog(null,
                        "Inserta la cantidad del producto"));
                        if(ls.findExistence(e)==2){
                            JOptionPane.showMessageDialog(null, "El producto no existe.");
                        }else if(ls.findQuantity(c)==2){
                            JOptionPane.showMessageDialog(null, "Producto Insuficiente\n"
                                    + "Ajuste su pedido.");
                        }else if(ls.findExistence(e)==0 || ls.findQuantity(c)==0){
                            JOptionPane.showMessageDialog(null, "Lista vacia.");
                        }
                    }while(ls.findExistence(e)!=1 || ls.findQuantity(c)!=1);
                    cl.insertFin(nom, e, c);
                    JOptionPane.showMessageDialog(null, "Usuario insertado correctamente.");
                break;
                case 12:
                    e=cl.obtenPedido();
                    c=cl.obtenCant();
                    price=ls.findPrice(e);
                    total=price*c;
                    cl.deleteIni();
                    ls.updateNodo(e, c);
                    ls.deleteCero();
                    JOptionPane.showMessageDialog(null, "Tu total a pagar es de: $"+total);
                break;
                case 13:
                    cl.printCola();
                break;
                case 20:
                    JOptionPane.showMessageDialog(null, 
                    "Gracias por su visita\nVuelva pronto =)");
                break;
                default:
                    JOptionPane.showMessageDialog(null, 
                    "Opcion no Reconocida\n Intentelo otra vez.");
                break;
            }
        }while(op!=20);
    }
}
