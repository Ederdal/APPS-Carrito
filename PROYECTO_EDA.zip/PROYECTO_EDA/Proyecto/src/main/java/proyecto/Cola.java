
package proyecto;

import javax.swing.JOptionPane;

public class Cola {
    private NodoPs inicio,fin;
    private String view="";
    public Cola(){
        inicio=fin=null;
    }
    public boolean colaVacia(){
        return inicio==null;
    }
    public void insertFin(String n,int e, int c){
        if(!colaVacia()){
            fin=new NodoPs(n,e,c,fin,null);
            fin.ant.sig=fin;
        }else{
            inicio=fin=new NodoPs(n,e,c);
        }
    }
    public void deleteIni() {
        if (!colaVacia()) {
            if (inicio == fin) {
                inicio = fin = null;
            } else {
                inicio = inicio.sig;
                if (inicio != null) {
                    inicio.ant = null;
                }
            }
            System.out.println("Pedido completado.");
        } else {
            System.out.println("Cola Vacia");
        }
    }
    public int obtenCant(){
        return inicio.cantidad;
    }
    public int obtenPedido(){
        return inicio.pedido;
    }
    public void printCola(){
        if(!colaVacia()){
            NodoPs recorrido=inicio;
            System.out.println("--------------------");
            while(recorrido!=null){
                System.out.println("Cliente: "+recorrido.nombre);
                System.out.println("Pedido: "
                        + "\n( Producto: "+recorrido.pedido+" Cantidad: "+recorrido.cantidad+" )");
                System.out.println("--------------------");
                /*view+="Cliente: "+recorrido.nombre+
                        "\nPedido: \n( Producto: "+
                        recorrido.pedido+" Cantidad: "+
                        recorrido.cantidad+" )\n";*/
                recorrido=recorrido.sig;
            }
        }else{
            //view="Lista Vacia";
            System.out.println("Lista Vacia");
        }
        //JOptionPane.showMessageDialog(null, view);
    }
}
