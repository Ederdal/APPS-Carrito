
package proyecto;

import javax.swing.JOptionPane;

public class Lista {
    private NodoPl inicio,fin;
    private int c=1;
    private String view="";
    public Lista(){
        inicio=fin=null;
    }
    public boolean listaVacia(){
        return inicio==null;
    }
    public void insertEnd(String n,int e,float p){
        if(!listaVacia()){
            fin=new NodoPl(c++,n,e,p,null,fin);
            fin.ant.sig=fin;
        }else{
            inicio=fin=new NodoPl(c++,n,e,p);
        }
    }
        
    public void printLista(){
        if(!listaVacia()){
            NodoPl recorrido=inicio;
            System.out.println("--------------------");
            while(recorrido!=null){
                System.out.println("No. "+recorrido.contador+"| Platillo: "+recorrido.nombre);
                System.out.println("Precio: "+recorrido.precio);
                System.out.println("Cantidad: "+recorrido.cantidad);
                System.out.println("--------------------");
                recorrido=recorrido.sig;
            }
        }else{
            System.out.println("Lista Vacia");
        }
    }
    
    public int findExistence(int n){
        if(!listaVacia()){
            NodoPl recorrido=inicio;
            while(recorrido.contador!=n && recorrido.sig!=null){
                recorrido=recorrido.sig;
            }
            if(recorrido.contador==n){
                System.out.println("Elemento Existe");
                return 1;
            }else{
                System.out.println("Elemento no existe");
                return 2;
            }
        }else{
            System.out.println("Lista Vacia");
            return 0;
        }
    }
    
    public float findPrice(int n){
        if(!listaVacia()){
            NodoPl recorrido=inicio;
            while(recorrido.contador!=n && recorrido.sig!=null){
                recorrido=recorrido.sig;
            }
            if(recorrido.contador==n){
                System.out.println("Elemento Existe");
                return recorrido.precio;
            }else{
                System.out.println("Elemento no existe");
                return recorrido.precio;
            }
        }else{
            System.out.println("Lista Vacia");
            return 0;
        }
    }
    
    public int findQuantity(int n){
        if(!listaVacia()){
            NodoPl recorrido=inicio;
            while( recorrido!=null && recorrido.cantidad<n){
                recorrido=recorrido.sig;
            }
            if( recorrido != null && recorrido.cantidad >= n ){
                System.out.println("Cantidad Suficiente");
                return 1;
            }else{
                System.out.println("Cantidad insuficiente");
                return 2;
            }
        }else{
            System.out.println("Lista Vacia");
            return 0;
        }
    }
        
    public void updateNodo(int e, int r) {
        if (!listaVacia()) {
            NodoPl recorrido = inicio;
            boolean encontrado = false;
            while (recorrido != null && !encontrado) {
                if (recorrido.contador == e) {
                    encontrado = true;
                } else {
                    recorrido = recorrido.sig;
                }
            }
            if (encontrado) {
                System.out.print("El elemento: " + recorrido.contador + " ha sido actualizado.\n");
                recorrido.cantidad -= r;
                System.out.print("Restan: " + recorrido.cantidad + " unidades.\n");
            } else {
                System.out.print("El elemento: " + e + " no existe.\n");
            }
        } else {
            System.out.print("La lista está vacía.\n");
        }
    }
    
    public void deleteCero() {
        if (!listaVacia()) {
            NodoPl recorrido = inicio;
            while (recorrido != null && recorrido.cantidad != 0) {
                recorrido = recorrido.sig;
            }
            if (recorrido != null) {
                System.out.println("Se encontró un nodo con cantidad igual a cero.");
            } else {
                System.out.println("No se encontraron nodos con cantidad igual a cero.");
            }
        } else {
            System.out.println("El menú está vacío.");
        }
    }

    
    public void findProduct(String n){
        if(!listaVacia()){
            NodoPl recorrido=inicio;
            while(recorrido.sig!=null && !recorrido.nombre.equals(n)){
                recorrido=recorrido.sig;
            }
            if(recorrido.nombre.equals(n)){
                System.out.println("El producto: "+recorrido.nombre+" existe.");
                System.out.println("Precio: "+recorrido.precio+"|Cantidad: "+recorrido.cantidad);
            }else{
                System.out.println("El producto: "+n+" no existe.");
            }
        }else{
            System.out.println("Lista Vacia");
        }
    }
}
