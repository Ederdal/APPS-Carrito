
package proyecto;

public class NodoPs {
    public String nombre;
    public int pedido;
    public int cantidad;
    public NodoPs ant,sig;
    
    public NodoPs(String n, int p, int c, NodoPs a,NodoPs s){
        nombre=n;
        pedido=p;
        cantidad=c;
        ant=a;
        sig=s;
    }
    public NodoPs(String n, int p, int c){
        nombre=n;
        pedido=p;
        cantidad=c;
        ant=null;
        sig=null;
    }
}
